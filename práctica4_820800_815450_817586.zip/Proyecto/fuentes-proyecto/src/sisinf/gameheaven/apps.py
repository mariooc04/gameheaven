from django.apps import AppConfig


class GameheavenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gameheaven'
